# 🌍 Deploy VibeDev — get a live URL, for free

This guide turns your local VibeDev into a **real hosted web app with its own domain** — no credit card, no server admin. Pick ONE option below; Render is the easiest end-to-end (hosts both the backend and the frontend together).

---

## Step 0 — Put it on GitHub first

VibeDev is already a clean, ready-to-upload git repo. From inside the folder:

```bash
cd vibedev
git remote add origin https://github.com/<YOUR-USERNAME>/vibedev.git
git push -u origin main
```

> If you haven't created the repo yet: go to **github.com/new**, name it `vibedev`, click **Create** (leave it empty — don't add a README), then run the two commands above.
>
> The repo already has a clean initial commit and a `.gitignore` that keeps secrets, `node_modules`, and build output off GitHub.

---

## Option A — Render.com (recommended, easiest) ⭐

Render deploys the **whole app** (backend + built frontend) and gives you a free `https://vibedev.onrender.com` URL.

1. Go to [render.com](https://render.com) → **Sign up** (free, no credit card).
2. **New → Blueprint** → select your `vibedev` GitHub repo.
3. Render reads the included `render.yaml`, builds the `Dockerfile`, and creates a free web service.
4. Click **Create resources** → wait ~2–4 min for the first build.
5. Open the URL it gives you (e.g. `https://vibedev.onrender.com`).

That's it. It auto-rebuilds on every `git push`.

---

## Option B — GitHub Codespaces (zero setup, great for demos)

The simplest way to run it *right now* without any hosting account:

1. Open your repo on GitHub → green **Code** button → **Codespaces** → **Create codespace**.
2. In the terminal run: `npm install && npm --prefix client install && npm run build:client && npm start`
3. When the port opens, GitHub forwards it to a public URL automatically.
4. **Forwarded Ports** → set the port to **Public** to share the link with anyone.

---

## Option C — Docker on any free host

Because `Dockerfile` and `render.yaml` are included, VibeDev runs on **Railway**, **Fly.io**, **Koyeb**, or a VPS with the same pattern:

```bash
docker build -t vibedev .
docker run -p 4000:4000 vibedev
```

| Host | Free tier | Steps |
|---|---|---|
| **Railway** | `railway.app` | New Project → **Deploy from GitHub** → pick repo → auto-detect Dockerfile |
| **Fly.io** | `fly.io` | `fly launch` in the folder, then `fly deploy` |
| **Koyeb** | `koyeb.com` | Create app → **Deploy from GitHub** → it builds the Dockerfile |

---

## Option D — Heroku (if you already use it)

```bash
./scripts/deploy-heroku.sh vibedev
```
(Pushes the built app to Heroku and opens it.)

---

## 🏷 Add your own custom domain (free or cheap)

Every free host gives you a `*.onrender.com` / `*.fly.dev` / `*.railway.app` URL by default. To use **your own domain**:

1. **Buy a domain** (a `.com` is ~$1–12/yr; `.tk`, `.eu.org` are free).
2. **Render:** Dashboard → your service → **Settings → Custom Domain** → add `app.yourdomain.com`.
3. At your domain registrar, add a **CNAME record**: `app → <your-service>.onrender.com`.
4. Wait up to an hour for DNS to propagate, then your site is live on your domain.

---

## 🔑 Enable real AI + GitHub on your hosted site

After deploying, add your keys so the hosted VibeDev uses real AI and real GitHub:

- **Render:** Dashboard → your service → **Environment** → add these, then **Deploy**:
  - `ANTHROPIC_API_KEY` (or `OPENAI_API_KEY`) and set `AI_PROVIDER=anthropic` (or `openai`/`auto`)
  - `GITHUB_CLIENT_ID` + `GITHUB_CLIENT_SECRET` (from a [GitHub OAuth app](https://github.com/settings/developers)) to enable the "Connect GitHub" button.
- **Before launch, always** change `AI_PROVIDER` from `mock` to a real provider, or leave it as `mock` for a public demo (it's still fully functional).

---

## ⚠️ Security checklist for going public

- [ ] `AI_PROVIDER` is set to a real provider or left as `mock` (never run a public deploy with unset keys and expect real AI).
- [ ] Your AI keys are only in the host's env settings, **not** in a committed `.env`.
- [ ] The built-in terminal is sandboxed (whitelisted commands + project-only), so it's safe to expose.
- [ ] Consider adding auth/a login before making it fully public to strangers (see README roadmap).

---

## Quick comparison

| Option | Backend+Frontend | Free domain | Setup time | Best for |
|---|---|---|---|---|
| **Render (Blueprint)** ⭐ | ✅ | `*.onrender.com` | ~5 min | Real hosted app |
| **Codespaces** | ✅ | GitHub-forwarded | ~1 min | Demos/sharing |
| **Docker (Railway/Fly/Koyeb)** | ✅ | yes | ~5 min | If you prefer these |
| **Heroku** | ✅ | `*.herokuapp.com` | ~5 min | Existing Heroku users |
