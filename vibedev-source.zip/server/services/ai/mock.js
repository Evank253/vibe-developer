import { detectLanguageKey, detectLanguage } from './languages.js';

// Mock/demo provider. No API key required.
// Performs real, deterministic checks so the app is genuinely useful out of the box.

const ISSUE_HEURISTICS = [
  {
    id: 'no-semicolon', name: 'Missing semicolon',
    langs: ['js', 'ts', 'java', 'c', 'cpp', 'cs', 'php', 'kt'],
    // lines ending in a value without semicolon (rough heuristic)
    test: (line) => /[)\]}0-9'\"]$/.test(line) && !/[;{}]$/.test(line) && !/^(\/\/|#|\*)/.test(line.trim()) && line.trim().length > 2
  },
  {
    id: 'tabs-vs-spaces', name: 'Mixed indentation',
    langs: ['js', 'ts', 'py', 'java', 'c', 'cpp', 'go', 'cs', 'rb', 'php', 'sh'],
    test: () => false // handled per-line in scan
  },
  {
    id: 'unused-import', name: 'Possible unused variable', langs: ['py'],
    test: () => false
  }
];

function scanFile(langKey, code) {
  if (!code) return [];
  const issues = [];
  const lines = code.split('\n');

  // Mixed indentation detection
  const indent = new Set();
  for (const l of lines) {
    const m = l.match(/^[ \t]+/);
    if (m) indent.add(m[0][0]);
  }
  if (indent.size > 1) {
    issues.push({ id: 'mixed-indent', severity: 'info', line: 1, message: 'Mixed tab/space indentation — normalize to spaces (2 or 4).' });
  }

  // Long lines
  lines.forEach((line, i) => {
    if (line.length > 160) {
      issues.push({ id: 'long-line', severity: 'info', line: i + 1, message: `Line ${i + 1} is ${line.length} chars — consider splitting for readability.` });
    }
    if (/^\s*todo\s*:/i.test(line) || /\/\/\s*todo/i.test(line) || /#\s*todo/i.test(line)) {
      issues.push({ id: 'todo', severity: 'info', line: i + 1, message: 'TODO/FIXME found — unfinished work may trip CI or reviewers.' });
    }
    // Trailing whitespace
    if (/[ \t]+$/.test(line) && line.trim().length > 0) {
      issues.push({ id: 'trailing-ws', severity: 'info', line: i + 1, message: `Trailing whitespace on line ${i + 1}.` });
    }
  });

  // Language-specific missing semicolon (rough)
  if (['js', 'ts', 'java', 'c', 'cpp', 'cs', 'kt'].includes(langKey)) {
    let prev = '';
    lines.forEach((line, i) => {
      const t = line.trim();
      const heuristic = /[^;{}]\s*$/.test(line) && /[)\]}"'0-9a-zA-Z]$/.test(t) && !/^(if|for|while|return\s*\()/.test(t) && t && !/^\s*(\/\/|\*|import|export|const|let|var|function|class|public|private|static|new|await|console\.log\s*=\s*)$/.test(t) && prev !== '}' && !t.startsWith('//');
      // Only flag obvious expression statements
      if (heuristic && !/[{};]$/.test(t) && t.length > 3 && !t.includes('=') && !t.startsWith('//')) {
        // keep it conservative
      }
      prev = t;
    });
  }

  return issues;
}

function parseTargets(code) {
  // Extract function/class names for organization context
  const funcs = [...code.matchAll(/\b(?:function\s+([A-Za-z0-9_]+)|def\s+([A-Za-z0-9_]+)|class\s+([A-Za-z0-9_]+)|\b(\w+)\s*=\s*(?:function|\(.*\)\s*=>))/g)]
    .map(m => m[1] || m[2] || m[3] || m[4]).filter(Boolean);
  return funcs;
}

function languageNameToKey(name) {
  const n = (name || '').toLowerCase();
  if (/javascript|js|node/i.test(n)) return 'js';
  if (/typescript|ts/i.test(n)) return 'ts';
  if (/python|py/i.test(n)) return 'py';
  if (/java\b/.test(n)) return 'java';
  if (/c\+\+|cpp|cpp/i.test(n)) return 'cpp';
  if (/c#|csharp|cs/i.test(n)) return 'cs';
  if (/\bc\b/.test(n)) return 'c';
  if (/go\b|golang/.test(n)) return 'go';
  if (/rust|rs\b/.test(n)) return 'rust';
  if (/ruby|rb\b/.test(n)) return 'rb';
  if (/php/.test(n)) return 'php';
  if (/swift/.test(n)) return 'swift';
  if (/kotlin|kt\b/.test(n)) return 'kt';
  if (/html/.test(n)) return 'html';
  if (/css|scss/.test(n)) return 'css';
  if (/sql/.test(n)) return 'sql';
  if (/shell|bash|sh\b/.test(n)) return 'sh';
  if (/solidity/.test(n)) return 'solidity';
  if (/dart/.test(n)) return 'dart';
  if (/vue/.test(n)) return 'vue';
  if (/svelte/.test(n)) return 'svelte';
  if (/json/.test(n)) return 'json';
  if (/yaml|yml/.test(n)) return 'yml';
  if (/markdown|md\b/.test(n)) return 'md';
  if (/dockerfile/.test(n)) return 'dockerfile';
  return 'js';
}

function fixLine(line) {
  return line;
}

export default {
  isMock: true,
  name: 'mock',

  async chat(messages, { system } = {}) {
    const last = messages[messages.length - 1]?.content || '';
    const text = last.toLowerCase();
    let reply = '';
    if (/(hi|hello|hey)\b/.test(text)) {
      reply = "Hey! 👋 I'm VibeDev, your AI super-developer. Drop a zip, tell me what to build, and I'll organize, fix, generate missing code, and deploy — no coding needed.";
    } else if (/organiz/.test(text)) {
      reply = "I can auto-organize any project into a clean, conventional structure (source in src/, tests in tests/, docs in docs/, etc.) and score it 100%. Upload a zip and I'll handle it.";
    } else if (/deploy/.test(text)) {
      reply = "Ready to deploy! I can push to GitHub and spin up a free host + domain (Render / GitHub Pages / Netlify). I'll build it, push it, and give you the live URL.";
    } else if (/fix|bug|error/.test(text)) {
      reply = "I'll scan your code for bugs, style issues, and missing pieces, then apply fixes automatically and show you exactly what changed.";
    } else if (/generate|build|make|create/.test(text)) {
      reply = "Tell me what you want in plain English — \"a to-do app with a login page\" — and I'll write the code for you in the language you need.";
    } else if (/github/.test(text)) {
      reply = "I'm connected to GitHub via OAuth or a Personal Access Token. I can create repos, commit your organized project, and push it for you.";
    } else {
      reply = "Got it. I can organize your project, review & fix code, generate code from plain language, or deploy it. Upload a zip or type what you want to build — I'll take it from there.";
    }
    return { role: 'assistant', content: reply, mock: true };
  },

  async reviewCode(files, { language } = {}) {
    // files: [{ path, content, language }]
    const results = [];
    let score = 100;
    for (const file of files || []) {
      const langKey = detectLanguageKey(file.path);
      const issues = scanFile(langKey, file.content);
      const severityWeight = { error: 8, warn: 4, info: 1 };
      for (const i of issues) score = Math.max(0, score - (severityWeight[i.severity] || 1));
      results.push({ path: file.path, language: detectLanguage(file.path), issues });
    }
    return { score, files: results };
  },

  async fixCode(files, { language } = {}) {
    const fixed = [];
    for (const file of files || []) {
      const langKey = detectLanguageKey(file.path);
      const issues = scanFile(langKey, file.content);
      let code = file.content || '';
      if (issues.some(i => i.id === 'trailing-ws')) {
        code = code.split('\n').map(l => l.replace(/[ \t]+$/, '')).join('\n');
      }
      // strip BOM, ensure trailing newline
      code = code.replace(/^\uFEFF/, '');
      if (code && !code.endsWith('\n')) code += '\n';
      fixed.push({ path: file.path, content: code, changed: code !== (file.content || '') });
    }
    return { fixed };
  },

  async generateCode(description, { language = 'Python' } = {}) {
    const lk = languageNameToKey(language);
    const templates = {
      py: `import sys

# ${description}
def main():
    print("Generated by VibeDev from your plain-English request.")

if __name__ == "__main__":
    main()
`,
      js: `// ${description}
'use strict';

function main() {
  console.log("Generated by VibeDev from your plain-English request.");
}

main();
`,
      ts: `// ${description}
function main(): void {
  console.log("Generated by VibeDev from your plain-English request.");
}

main();
`,
      java: `// ${description}
public class Main {
    public static void main(String[] args) {
        System.out.println("Generated by VibeDev from your plain-English request.");
    }
}
`,
      default: `// ${description}
// Generated by VibeDev from your plain-English request.
console.log("Hello from VibeDev!");
`
    };
    const code = templates[lk] || templates.default;
    return {
      language: detectLanguage('.' + (lk === 'plain' ? 'txt' : lk)),
      fileName: lk === 'py' ? 'main.py' : lk === 'js' ? 'index.js' : lk === 'ts' ? 'index.ts' : lk === 'java' ? 'Main.java' : 'index.' + (lk === 'plain' ? 'js' : lk),
      code,
      explanation: `Generated a starter ${language} program for: ${description}`
    };
  },

  async organizeFiles(files) {
    // files: [{ path, size }]
    const plan = [];
    const src = [], tests = [], docs = [], assets = [], config = [], root = [];
    const pathLow = f => f.path.toLowerCase();

    for (const f of files || []) {
      const p = pathLow(f);
      if (/(test|spec)\.|__tests__|tests?\/|test_/.test(p)) tests.push(f.path);
      else if (/\.(md|rst|txt)$/.test(p) && /\b(readme|docs?|changelog|license|contribut)\b/.test(p)) docs.push(f.path);
      else if (/\.(png|jpg|jpeg|gif|svg|ico|webp|woff2?|ttf|mp4|mp3|pdf)$/.test(p)) assets.push(f.path);
      else if (/\.(json|ya?ml|toml|ini|cfg|conf|env|gitignore|lock|xml|config|eslintrc|prettierrc|babelrc|dockerfile)$/.test(p)) config.push(f.path);
      else if (/^\.\w+$/.test(p.split('/').pop())) root.push(f.path);
      else if (/src\/|lib\/|app\/|components?\/|pages\/|routes?\//.test(p)) src.push(f.path);
      else if (/\.(js|ts|py|java|c|cpp|go|rb|php|rs|swift|kt|cs|html|css|scss|jsx|tsx|vue|svelte)$/.test(p)) src.push(f.path);
      else root.push(f.path);
    }

    plan.push({ folder: 'src/', files: src, reason: 'Source code belongs in src/ (or stays if already structured).' });
    plan.push({ folder: 'tests/', files: tests, reason: 'Test/spec files grouped under tests/.' });
    plan.push({ folder: 'docs/', files: docs, reason: 'Documentation (README, guides, licenses) under docs/.' });
    plan.push({ folder: 'assets/', files: assets, reason: 'Static/media assets under assets/.' });
    plan.push({ folder: '(root config)', files: config, reason: 'Config/build files stay at the project root for tooling to find them.' });
    plan.push({ folder: '(root)', files: root, reason: 'Entry points and dotfiles kept at root.' });

    return { plan, stats: { total: (files || []).length, src: src.length, tests: tests.length, docs: docs.length, assets: assets.length, config: config.length, root: root.length } };
  },

  async addMissingCode(project) {
    // project: { files: [{path, content}], name }
    const missing = [];
    const has = p => project.files.some(f => f.path.toLowerCase() === p.toLowerCase());
    const name = project.name || 'my-project';
    const langKey = detectLanguageKey(project.files[0]?.path || '');

    if (!has('README.md')) {
      missing.push({
        path: 'README.md',
        reason: 'No README found — adding one so reviewers and collaborators understand the project.',
        content: `# ${name}

Built & organized with **VibeDev**.

## Features
- Clean, conventional project structure
- Auto-organized, reviewed, and ready to ship

## Getting Started
1. \`npm install\` (or your language's package manager)
2. Run the project
3. Done!

## Support
Questions? Ask the VibeDev copilot — no coding needed.
`
      });
    }

    if (!has('.gitignore')) {
      const langGitignore = langKey === 'py' ? 'venv/\n__pycache__/\n*.pyc\n.env\n' : 'node_modules/\ndist/\nbuild/\n.env\ncoverage/\n';
      missing.push({
        path: '.gitignore',
        reason: 'No .gitignore found — adding one so secrets & build artifacts never get committed.',
        content: `# VibeDev generated .gitignore\n${langGitignore}`
      });
    }

    if (!has('package.json') && ['js', 'ts', 'jsx', 'tsx'].includes(langKey)) {
      missing.push({
        path: 'package.json',
        reason: 'Detected a JS/TS project with no package.json — adding a valid manifest.',
        content: `{
  "name": "${name.toLowerCase().replace(/[^a-z0-9-]/g, '-')}",
  "version": "1.0.0",
  "description": "Generated by VibeDev",
  "main": "index.js",
  "scripts": {
    "start": "node index.js"
  },
  "license": "MIT"
}
`
      });
    }

    return { added: missing };
  }
};
